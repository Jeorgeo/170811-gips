<?php if (!defined('FW')) {
    die('Forbidden');
}

$options = array(
    'id'  => array(
        'label' => 'Slider ID',
        'type'  => 'text',
        'value' => ''
    ),
);
